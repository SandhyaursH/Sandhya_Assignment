#!/bin/bash



echo "======================================="
echo "        AUTOMATED BACKUP SCRIPT        "
echo "======================================="


read -p "Enter directory to backup: " SOURCE

if [ ! -d "$SOURCE" ]; then
    echo "❌ Error: Source directory does not exist."
    exit 1
fi


read -p "Enter backup destination: " DEST


mkdir -p "$DEST"


echo "Backup Type:"
echo "1. Simple copy"
echo "2. Compressed archive (tar.gz)"
read -p "Enter choice (1 or 2): " CHOICE

TIMESTAMP=$(date +%Y%m%d_%H%M%S)

START=$(date +%s)

echo "[*] Starting backup..."
echo "[*] Source: $SOURCE"
echo "[*] Destination: $DEST"

if [ "$CHOICE" -eq 1 ]; then
    BACKUP_NAME="backup_$TIMESTAMP"
    cp -r "$SOURCE" "$DEST/$BACKUP_NAME"
    BACKUP_PATH="$DEST/$BACKUP_NAME"
    echo "[*] Creating simple copy..."
    
elif [ "$CHOICE" -eq 2 ]; then
    BACKUP_NAME="backup_$TIMESTAMP.tar.gz"
    tar -czf "$DEST/$BACKUP_NAME" -C "$(dirname "$SOURCE")" "$(basename "$SOURCE")"
    BACKUP_PATH="$DEST/$BACKUP_NAME"
    echo "[*] Creating compressed archive..."
    
else
    echo " Invalid choice."
    exit 1
fi

END=$(date +%s)
DURATION=$((END - START))


if [ -e "$BACKUP_PATH" ]; then
    echo " Backup completed successfully!"
else
    echo " Backup failed."
    exit 1
fi

SIZE=$(du -sh "$BACKUP_PATH" | awk '{print $1}')

echo ""
echo "========== Backup Details =========="
echo "File: $BACKUP_NAME"
echo "Location: $DEST"
echo "Size: $SIZE"
echo "Time taken: $DURATION seconds"
echo "====================================="


echo "[*] Checking old backups..."
cd "$DEST"
ls -t backup_* 2>/dev/null | tail -n +6 | xargs -r rm --

LOGFILE="$DEST/backup.log"
echo "[$(date)] Backup created: $BACKUP_NAME | Size: $SIZE | Time: $DURATION sec" >> "$LOGFILE"

echo "[*] Log updated at $LOGFILE"

exit 0
