Name: Sandhya Urs H
Assignment: CampusPe Bash Scripting Assignment

Questions Attempted:
Q1 - System Information Script
Q2 - File Manager
Q3 - Log Analyzer
Q4 - Backup Script
Q5 - User Report

How to Run:
./q1_system_info.sh
./q2_file_manager.sh
./q3_log_analyzer.sh
./q4_backup.sh
./q5_user_report.sh

Sample Test Cases:
Executed scripts using terminal commands.

Challenges Faced:
Debugging bash errors and understanding commands.
